# Discord-WL-Bot
Bot assigning roles to WL users
